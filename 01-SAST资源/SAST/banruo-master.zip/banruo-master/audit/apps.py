from django.apps import AppConfig


class AduitConfig(AppConfig):
    name = 'audit'
