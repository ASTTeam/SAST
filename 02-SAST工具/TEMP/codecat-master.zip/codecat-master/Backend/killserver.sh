fuser -k -n tcp 50093
fuser -k -n tcp 50001
