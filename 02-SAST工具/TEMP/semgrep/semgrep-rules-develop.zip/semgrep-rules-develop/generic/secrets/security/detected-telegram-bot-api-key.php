<?php

// ruleid: detected-telegram-bot-api-key
define('BOT_TOKEN', '12345678:AA101703Wd8JLT6GCtKzxatRHQREQUk_CpK');
define('API_URL', 'https://api.telegram.org/bot'.BOT_TOKEN.'/');

// ok: detected-telegram-bot-api-key
define('GO.MOD', 'github.com/gorilla/mux v1.7.4/go.mod 11:AAbg23sWSpFRCP0SfiEN6jmj59UnWan46BH5rLB7');
// ok: detected-telegram-bot-api-key
define('DO_NOT_DETECT_ME', 'github.com/valyala/fasthttp v1.24.0 h1:AAiG4oLDUArTb7rYf9oO2bkGooOqCaUF6a2u8asBP3I=')

?>
