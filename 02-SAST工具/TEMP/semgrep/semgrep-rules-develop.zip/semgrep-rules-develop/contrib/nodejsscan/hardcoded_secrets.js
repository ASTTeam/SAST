// ruleid:node_password
password = '1212';
x = 1;
password = x;
pass = 123;
// ruleid:node_password
PASSWORD = '12211';

// ruleid:node_password
obj['password'] = '121233';
// ruleid:node_password
obj2.password = '1234';
// ruleid:node_password
obj2.pass = '1234';
// ruleid:node_password
obj2["pass"] = '1234';

// ruleid:node_password
const password = '1212';
// ruleid:node_password
let password = '1212';
// ruleid:node_password
var password = '1212';

// ruleid:node_api_key
angular.module('starter.services', [])
    .constant('api_key', '6e906986c3b199c51fff3154cfb76979')
this.apiUrl = api_url;
