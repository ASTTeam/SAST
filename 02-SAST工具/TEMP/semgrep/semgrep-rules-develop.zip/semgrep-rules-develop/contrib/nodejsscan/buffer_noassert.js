// ruleid:buffer_noassert
a.readUInt8(0, true)
