package classfile

/*
Synthetic_attribute {
    u2 attribute_name_index;
    u4 attribute_length;
}
*/

type SyntheticAttribute struct {
	MarkerAttribute
}
