package classfile

type MarkerAttribute struct{}

func (c *MarkerAttribute) readInfo(_ *ClassReader) {
}
