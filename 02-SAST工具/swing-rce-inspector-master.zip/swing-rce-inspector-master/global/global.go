package global

import "github.com/4ra1n/swing-rce-inspector/classfile"

// CP
// IMPORTANT: current constant pool
var CP classfile.ConstantPool
