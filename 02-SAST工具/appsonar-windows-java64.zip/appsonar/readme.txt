About:
AppSonar is a application security and quality testing tool that automates static code analysis by finding hidden security and quality bugs faster.

Author:
AppSonar is created by CyberTest security engineers, researchers and testers. CyberTest offers comprehensive penetration testing services and tools.
To learn more about CyberTest please visit www.cybertest.com.

Terms and Conditions:
By using AppSonar software you agree the terms and conditions published at https://www.appsonar.com/terms

Update: 
AppSonar version 3.1.0 released on November 14, 2022.

Requirements:
64 bit Java/OpenJDK version 8 or above.
Windows OS.

Extensions:
To scan SAP ABAP code, download the extensions from https://www.appsonar.com/download-extensions. Then uncomment the extensions from appsonar.cfg.

Whats new:
- New rules.

- Bug fixes.

- Added new attribute called "scancategory" in appsonar.cfg. By default this attribute is set to 0 which means scan all categories. If you set this 
  to 1 it will scan hard coded credentials. If set to 2 it will scan cryptography weaknesses. For rest of the attributes please
  refer to https://www.appsonar.com/documentation.

- Dependency scan now supports excluding files by CVE id in appsonar.cfg file. Example: exclude=CVE-<id number>:<file name/path>.
  To exclude CVE on all files, use * instead of file name/path.


Help:
Visit https://www.appsonar.com/documentation. For questions or support please contact info@appsonar.com.

